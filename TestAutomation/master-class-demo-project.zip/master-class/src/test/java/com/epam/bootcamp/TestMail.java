package com.epam.bootcamp;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class TestMail {
    protected WebDriver driver;
    private static final String TEST_URL = "https://mail.yandex.by/";
    private static final String EMAIL = "master.class.test";

    @BeforeClass
    public void setUp() {
        if (driver == null) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.manage().window().maximize();
            driver.get(TEST_URL);
        }
    }

    @Test
    public void login() throws InterruptedException {
        driver.findElement(By.xpath("//span[text()='Войти']/parent::a")).click();
        driver.findElement(By.id("passp-field-login")).sendKeys(EMAIL);
        driver.findElement(By.xpath("//div[@class='passp-button passp-sign-in-button']/button")).click();
        driver.findElement(By.id("passp-field-passwd")).sendKeys("test_for_mentee");
        driver.findElement(By.xpath("//div[@class='passp-button passp-sign-in-button']/button")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//a[contains(@class,'user-account_left-name')]/span[@class='user-account__name']")).getText().contains(EMAIL));
        Thread.sleep(5000);
    }

    @AfterClass
    public void reset() {
        driver.quit();
        driver = null;
    }
}
